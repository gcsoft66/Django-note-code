import random
import time

from django.core.cache import cache
from django.http import HttpResponse
from django.shortcuts import redirect
from django.urls import reverse

from django.utils.deprecation import MiddlewareMixin


class HelloMiddle(MiddlewareMixin):

    def process_request(self, request):
        print(request.META.get("REMOTE_ADDR"))  # 打印统计访问网站的ip

        # 白名单提高优先级
        ip = request.META.get("REMOTE_ADDR")
        if request.path == "/myPrint/getphone/":
            if ip == "127.0.0.1":
                if random.randrange(100) > 20:
                    return HttpResponse("恭喜你免费获得小米8 256G版")

        # 黑名单
        if request.path == "/myPrint/getyh/":
            # ip.startswith("10.0.122.7")以7系列开头的
            if ip.startswith("10.0.122.7"):
                return HttpResponse("已抢光")

        # 实现访问限制
        if request.path == "/myPrint/search/":
            # 这里可以用缓存记录搜索次数
            result = cache.get(ip)
            if result:
                return HttpResponse("您的访问过于频繁，请10秒后在尝试")
            cache.set(ip, ip, timeout=10)

'''
    # 界面友好化
    def process_exception(self, request, exception):
        print(request, exception)
        # 重名项，如果网站有异常，跳转到其他页面
        return redirect(reverse("myPrint:home"))



        # 1分钟访问10次，反爬
        black_list = cache.get("black", [])
        if ip in black_list:
            return HttpResponse("黑名单用户，凉凉")

        requests = cache.get(ip, [])
        # 如果列表有数据，并且最后一条数据大于60，则弹出去，ime.time()当前时间，requests[-1]最后一条数据
        while requests and time.time()-requests[-1] > 60:
            requests.pop()

        requests.insert(0, time.time())
        cache.set(ip, requests, timeout=60)

        if len(requests) > 30:
            black_list.append(ip)
            cache.set('black', black_list, timeout=60*60*24)
            return HttpResponse("小爬虫小黑屋里面待着")
        if len(requests) > 10:
            # 封杀ip
            return HttpResponse("请求次数过于频繁")
'''
