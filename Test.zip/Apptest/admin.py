from django.contrib import admin

# Register your models here.
# 配置富文本站点
# admin.site.register