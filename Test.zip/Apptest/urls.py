#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from django.urls import path
from . import views

urlpatterns = [
    path('add_User/', views.add_User),
    path('grade/', views.gGrade),  # 获取学生对应的班级
    path('students/', views.Students),  # 获取班级对应的学生
    path('presons/', views.Presons, ),
    path('getpresons/', views.Getpresons),
    path('addpreson/', views.Add_preson),
    path('getuser/', views.GetUsers),
    path('ccorder/', views.ccOrder),
    path('Stu/', views.Stu),
    path('ganimals/', views.Get_animals, ),
    path('getstudents/', views.get_students),  # 进行反向解析，动态获取url路径，可以根据namespace：name找到def xxx
    path('gdate/<int:pk>/<int:pc>/', views.Gdate, name='date'),  # 参数传递动态获取
    path('article/', views.Article, name='article'),  # 不传递参数动态获取
    path('imagefile/', views.image_file, name='image_file'),  # 上传文件
    path('news/', views.news, name='news'),  # 新闻，缓存的使用
    path('home/', views.home, name='home'),
    path('getphone/', views.get_phone, name='getphone'),
    path('getyh/', views.get_th, name='getyh'),
    path('search/', views.search, name='search'),
    path('calc/', views.calc, name='calc'),
    path('login/', views.login, name='login'),
    path('gstudents/', views.get_students),
    path('sstudents/', views.set_students),
    path('gstudentsfyq/', views.get_studentsfyq, name='fyq'),
    path('getcode/', views.get_code, name='getcode'),  # 原生绘制验证码
    path('editblog/', views.edit_blog, name='editblog'),  # 富文本
    path('index/', views.test),  # test
]