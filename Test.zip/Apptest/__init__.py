# python manage.py runserver
# pip install -i https://pypi.doubanio.com/simple/ Django
# pip install -i https://pypi.doubanio.com/simple/ pymysql
# pip install -i https://pypi.doubanio.com/simple/ Pillow
# pip install -i https://pypi.doubanio.com/simple/ django-tinymce
# pip install -i https://pypi.doubanio.com/simple/ django-simple-captcha