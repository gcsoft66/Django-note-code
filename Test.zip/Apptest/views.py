# Create your views here.
import os
import random

from io import BytesIO

from PIL import Image, ImageFont
from PIL.ImageDraw import ImageDraw
from django.conf import settings

from django.core.cache import caches
from django.core.paginator import Paginator
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.urls import reverse
from django.views.decorators.csrf import csrf_exempt
from .models import Student, Grade, Preson, Animal, UserModel, Stude, myBlog, User, Order
from .utils import get_color, generate_code


def add_User(request):
    #  #增数据
    user = User()  # 初始化用户表
    user.u_name = "181040200222"
    user.save()  # 存储用户信息数据
    #  #查数据
    users = User.objects.all()  # 查数据
    for user in users:
        print(user.u_name)  # 打印数据
    # context字典，render的第三个参数进行在前端传数据
    context = {
        "users": users
    }

    #  #改数据，更新数据
    user = User.objects.get(pk=25)  # 查询主键值为25的数据
    user.u_name = "2018101800"  # 改主键为25数据
    user.save()

    #  #删数据
    user = User.objects.get(pk=27)  # 查询主键值为27的数据
    user.delete()  # 删除主键为27的数据

    # return HttpResponse("添加成功")
    return render(request, 'present.html', context=context)


# 级联数据查询
def gGrade(request):
    # 查询主键为1学生的班级
    student = Student.objects.get(pk=1)
    grade = student.s_grade
    context = {
        "grade": grade
    }
    return render(request, 'grade.html', context=context)


def Students(request):
    # 查询主键为1班级的学生
    grade = Grade.objects.get(pk=1)
    students = grade.student_set.all()
    context = {
        "students": students
    }
    return render(request, 'students.html', context=context)


#
def Presons(request):
    for i in range(15):
        preson = Preson()
        flag = random.randrange(100)  # 随机数
        preson.p_name = "Tom%d" % flag
        preson.p_age = flag
        preson.p_sex = flag % 2
        preson.save()
    return HttpResponse("批量创建成功")


def Getpresons(request):
    # presons = Preson.objects.filter(p_age__gt=50).filter(p_age__lt=80)  # 年龄 满足 _gt=大于 _lt=小于
    # presons = Preson.objects.exclude(p_age__lt=50)  # 年龄 不满足
    # presons = Preson.objects.exclude(p_age__lt=50).filter(p_age__gt=80)
    presons = Preson.objects.all().order_by("-id")  # 默认根据ID从小到大排序，order_by是排序
    # presons = Preson.objects.all()order_by("p_age")  # 根据年龄排序

    # 一条数据就是一个字典，将数据返回到一个列表
    presons_values = presons.values()
    for values in presons_values:
        print(values)
    context = {
        "presons": presons
    }

    return render(request, 'preson_list.html', context=context)


def Add_preson(request):
    #  是"" 而非 None Null 不能重写__init__ 可以通过其他手段，实现属性自定义默认赋值
    preson = Preson.create('Jack')  # 其他的两个属性则默认为100和1
    preson.save()
    return HttpResponse("创建成功")


def GetUsers(request):
    person = Preson.objects.all()[1:3]  # 切片，左闭右开，下标不能是负数

    context = {
        "users": person
    }
    return render(request, 'userlist.html', context)


def ccOrder(request):
    corder = Order.objects.filter(
        o_time__year=2019)  # 根据年份查询，还有__month月份,如果时区有问题，可以关闭Django中的时区，settings.py中USE_TZ = False即可
    return HttpResponse("获取订单成功")


# 跨关系查询，查询学生所在的班级
def Stu(request):
    gread = Grade.objects.filter(student__s_name='fcck')
    for greads in gread:
        print(greads.g_name)

    return HttpResponse("获取成功")


def Get_animals(request):
    animals = Animal.objects.all()
    for animal in animals:
        print(animal.a_name)
    # create_animal创建对象
    # Animal.objects.create_animal("狗")

    return HttpResponse("动物获取成功")


# 模板templates
def get_students(request):
    students = Student.objects.all()
    context = {
        "students": students
    }
    return render(request, 'tests.html', context=context)


def Article(request):
    return HttpResponse("Love Article")


def Gdate(request, pk, pc):
    return HttpResponse("Time %s: %s" % (pk, pc))


# 文件上传
def image_file(request):
    if request.method == "GET":
        return render(request, "image.html")
    elif request.method == "POST":
        username = request.POST.get("username")
        icon = request.FILES.get("icon")
        user = UserModel()
        user.u_name = username
        user.u_icon = icon
        user.save()
        return HttpResponse("成功")


'''
数学函数，计算，可以用聚合函数查询
F对象
可以获取属性值
可以实现一个模型不同的运算操作
还可以支持算术运算
Q对象
可以对条件进行封装，封装之后，可以支持逻辑运算 或|与&非~
'''


# 缓存,提升响应速度
# @cache_page(60 * 30, cache='default')  # 缓存数据库使用default,数据库缓存目前由于缺少import pylibmc，并且windows装不上，该块暂时无法实践
# 如果没有缓存，自动加载到数据库，然后缓存
def news(request):
    cache = caches['redis_backend']  # 设置缓存的数据库
    result = cache.get("news")
    if result:
        return HttpResponse(result)
    news_list = []
    for i in range(10):
        news_list.append("最近肺炎病毒很严重%d" % i)  # append()方法用于在列表末尾添加新的对象
    context = {
        'news_list': news_list
    }
    # time.sleep(5)  # 假装耗时5s，@cache_page(60 * 30, cache='default')
    response = render(request, "news.html", context=context)
    cache("news", response.content, timeout=60)
    return response


# pip install -i https://pypi.doubanio.com/simple/ Django-redis-cache
def home(request):
    return HttpResponse('home')


# 白名单
def get_phone(request):
    if random.randrange(100) > 95:
        return HttpResponse("恭喜你抢到小米8")
    return HttpResponse("正在排队")


# 黑名单
def get_th(request):
    if random.randrange(100) > 10:
        return HttpResponse("还剩余99张优惠券")
    return HttpResponse("优惠券被抢光了")


# 搜索，用中间件实现
def search(request):
    return HttpResponse("这是你搜索到的资源")


def calc(request):
    a = 250
    b = 250
    result = (a + b) / 0
    return HttpResponse(result)


# 给创建100个数据，实现分页器
def set_students(request):
    for i in range(100):
        student = Stude()
        student.s_name = "小明%d" % i
        student.s_age = i
        student.save()
    return HttpResponse("学生创建成功")


# 获取100个学生数据，实现原生分页
def get_students(request):
    page = int(request.GET.get("page", 1))  # 一页数据
    per_page = int(request.GET.get("per_page", 10))  # 每页10条数据
    students = Stude.objects.all()[per_page * (page - 1): page * per_page]  # 第几页：到第几条数据为止
    # http://127.0.0.1:8000/myPrint/gstudents/?page=1&per_page=10 每页10条
    # http://127.0.0.1:8000/myPrint/gstudents/?page=2&per_page=20 第二页的20条

    data = {
        "students": students
    }
    return render(request, 'stude.html', context=data)


def get_studentsfyq(request):
    page = int(request.GET.get("page", 1))  # 一页数据
    per_page = int(request.GET.get("per_page", 10))  # 每页10条数据
    students = Stude.objects.all()
    paginator = Paginator(students, per_page)
    page_object = paginator.page(page)
    data = {
        "page_object": page_object,
        "page_range": paginator.page_range,  # 加页码
    }
    return render(request, 'studentsfyq.html', context=data)


# 添加内置豁免权（装饰器），不会出现CSRF验证失败，请求被中断
@csrf_exempt
def login(request):
    if request.method == "GET":
        return render(request, "Login.html")
    elif request.method == "POST":
        receive_code = request.POST.get("verify")
        store_code = request.session.get("verify")
        if receive_code != store_code:  # 不区分大小写if receive_code.lower() != store_code.lower():
            return redirect(reverse('Apptest:login'))
        return HttpResponse("登录成功")


# 原生绘制验证码
def get_code(request):
    # 初始化画布，初始化画笔
    mode = "RGB"
    size = (200, 100)
    reg = get_color()
    green = get_color()
    blue = get_color()
    color = (reg, green, blue)
    image = Image.new(mode=mode, size=size, color=color)
    # 画笔
    imagedraw = ImageDraw(image, mode=mode)
    imagefont = ImageFont.truetype(settings.FONT_PATH, 75)  # 加载自己的字体
    verify = generate_code()
    # 保存验证码，绑定浏览器
    request.session['verify'] = verify

    for i in range(4):
        fill = (get_color(), get_color(), get_color())
        imagedraw.text(xy=(50 * i, 0), text=verify[i], font=imagefont, fill=fill)  # 使用自己的字体画
    # 画干扰点10000个
    for i in range(10000):
        fill = (get_color(), get_color(), get_color())
        xy = (random.randrange(201), random.randrange(100))
        imagedraw.point(xy=xy, fill=fill)
    # 造一个内存流
    fp = BytesIO()
    # 因为验证码存到服务器没有什么用，所以存到内存，称内存流
    image.save(fp, "png")
    # 以上还可以画干扰线，旋转角度
    return HttpResponse(fp.getvalue(), content_type="image/png")


def edit_blog(request):
    if request.method == "GET":
        return render(request, 'editblog.html')
    elif request.method == "POST":
        content = request.POST.get("content")
        print(content)
        blog = myBlog()
        blog.b_content = content
        blog.save()
        return HttpResponse("提交成功")


def test(request):
    return render(request, "index.html")
