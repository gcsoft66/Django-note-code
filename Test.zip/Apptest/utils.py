import random


def get_color():
    return random.randrange(256)


def generate_code():
    source = "gduwqfiwqhfwqjwfjqjfpowqjf1234567890QQWFDWQFQKJFQKFKNFKNLKFNVMMV"
    code = ""
    for i in range(4):
        code += random.choice(source)
    return code
